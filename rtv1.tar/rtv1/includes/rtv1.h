/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rtv1.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbenjami <rbenjami@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/24 16:33:02 by dsousa            #+#    #+#             */
/*   Updated: 2014/02/15 17:41:12 by rbenjami         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RTV1_H
# define RTV1_H

# define WIN_H 720
# define WIN_W 1080

# define MAX_PLAN 5
# define MAX_PROJ 5
# define MAX_SPHERE 30
# define MAX_CYLINDER 30
# define MAX_CONE 30

# define TYPE_CAM 0
# define TYPE_PROJ 1
# define TYPE_SPHERE 2
# define TYPE_PLAN 3
# define TYPE_CYLINDER 4
# define TYPE_CONE 5

typedef struct			s_vector
{
	float				x;
	float				y;
	float				z;
}						t_vector;

typedef	t_vector		t_ray;

typedef struct			s_obj
{
	int					type;
	int					red;
	int					green;
	int					blue;
	float				intens;
	float				diameter;
	float				x;
	float				y;
	float				z;
	float				rot_x;
	float				rot_y;
	float				rot_z;
}						t_obj;

typedef struct			s_elem
{
	int					count_obj;
	int					nb_cam;
	int					nb_plan;
	int					nb_proj;
	int					nb_sphere;
	int					nb_cylinder;
	int					nb_cone;
}						t_elem;

typedef struct			s_scene
{
	int					shadow;
	int					brightness;
	t_elem				elem;
	t_obj				cam;
	t_obj				plan[MAX_PLAN];
	t_obj				proj[MAX_PROJ];
	t_obj				sphere[MAX_SPHERE];
	t_obj				cylinder[MAX_CYLINDER];
	t_obj				cone[MAX_CONE];
}						t_scene;

typedef struct			s_line
{
	char				var[50];
	float				value;
}						t_line;

typedef struct			s_img
{
	void				*img;
	char				*data;
	int					endian;
	int					sizeline;
	int					bpp;
}						t_img;

typedef struct			s_color
{
	int					red;
	int					green;
	int					blue;
}						t_color;

typedef struct			s_plan
{
	float				x;
	float				y;
	float				z;
}						t_plan;

typedef struct			s_env
{
	t_scene				*scene;
	void				*win;
	void				*mlx;
	t_img				screen;
}						t_env;

typedef struct			s_dist
{
	float				a;
	float				b;
	float				c;
	float				d;
}						t_dist;

typedef struct			s_handler
{
	int					h;
	int					w;
	char				*tmp;
	t_color				color;
	t_ray				ray;
	t_vector			cam;
}						t_handler;

/*
**	error.c
*/
int			error(const char *s1, char *s2, int exit_bool, int details);

/*
**	parse.c
*/
t_scene		parse(char *file);

/*
**	render.c
*/
int			render(t_env *env, t_scene *scene);
float		ft_atod(char *str);

/*
**	vector.c
*/
t_vector	normine(t_vector v);
t_vector	multi(t_vector vector, float m);
t_vector	vec3(float x, float y, float z);
float		dot(t_vector a, t_vector b);
float		dist(t_vector v1, t_vector v2);

/*
**	math.c
*/
float		rt(float val);
float		res(float a, float b, float c);
t_vector	normal_plan(float rotx, float roty, float rotz);

/*
**	color.c
*/
t_color		rgb(int r, int g, int b);
t_color		add(t_color a, t_color b);
t_color		mul(t_color a, float b);

/*
**	light.c
*/
t_color		get_light_at(t_scene *scene, t_vector inter, t_obj obj);

/*
**	object.c
*/
float		sphere(t_scene *scene, t_vector cam, t_obj sphere, t_ray ray);
float		plan(t_scene *scene, t_vector cam, t_obj plan, t_ray ray);
float		cylinder(t_scene *scene, t_vector cam, t_obj cylinder, t_ray ray);
float		cone(t_scene *scene, t_vector cam, t_obj cone, t_ray ray);

/*
**	shadow.c
*/
float		shadow(t_scene *scene, t_vector v);

/*
**	tracer.c
*/
t_color		trace_spheres(t_scene *s, t_vector cam, t_ray ray, float *d);
int			trace_cylinder(t_scene *s, t_vector cam, t_ray ray, float *d);
int			trace_cone(t_scene *s, t_vector cam, t_ray ray, float *d);
int			trace_plan(t_scene *s, t_vector cam, t_ray ray, float *d);

/*
**	hook.c
*/
int			expose_hook(t_env *e);
int			key_hook(int keycode, t_env *e);

/*
**	verify.c
*/
void		check_clean_line(t_line *l, int *nb_line, char *line);

/*
**	init.c
*/
t_obj		init_obj(int type);
void		init_dist(t_dist *d);
t_vector	init_cam(t_scene *scene);

#endif /* RTV1_H */
