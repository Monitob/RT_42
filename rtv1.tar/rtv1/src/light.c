/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   light.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbenjami <rbenjami@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/12 11:17:15 by rbenjami          #+#    #+#             */
/*   Updated: 2014/02/15 17:17:20 by rbenjami         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <math.h>
#include <libft.h>
#include "rtv1.h"

static t_vector		get_normal(t_scene *scene, t_vector inter, t_obj obj)
{
	t_vector	norm;
	float		x;
	float		y;
	float		z;

	x = inter.x - (obj.x - scene->cam.x);
	y = inter.y - (obj.y - scene->cam.y);
	z = inter.z - (obj.z - scene->cam.z);
	norm = vec3(0, 0, 0);
	if (obj.type == TYPE_SPHERE)
		norm = vec3(x, y, z);
	else if (obj.type == TYPE_PLAN)
		norm = normal_plan(obj.rot_x, obj.rot_y, obj.rot_z);
	else if (obj.type == TYPE_CYLINDER)
		norm = vec3(x, 0, z);
	else if (obj.type == TYPE_CONE)
		norm = vec3(x, -y * tan(rt(obj.diameter / 2)), z);
	return (norm);
}

t_vector			get_light_vec(t_scene *scene, t_vector inter, int i)
{
	t_vector	light_vector;

	light_vector.x = (scene->proj[i].x - scene->cam.x) - inter.x;
	light_vector.y = (scene->proj[i].y - scene->cam.y) - inter.y;
	light_vector.z = (scene->proj[i].z - scene->cam.z) - inter.z;
	light_vector = normine(light_vector);
	return (light_vector);
}

t_color				get_light_at(t_scene *scene, t_vector inter, t_obj obj)
{
	t_vector	light_vector;
	float		angle[MAX_PROJ];
	float		a;
	float		c;
	int			i;

	i = 0;
	a = 0;
	c = 0;
	while (i < scene->elem.nb_proj)
	{
		light_vector = get_light_vec(scene, inter, i);
		angle[i] = dot(light_vector, get_normal(scene, inter, obj));
		if ((angle[i] <= 1 && angle[i] >= 0.95) && scene->brightness == TRUE)
			c += (((angle[i] - 0.95) / 0.05) * scene->proj[0].intens);
		if (!(angle[i] <= 0))
			a += angle[i];
		i++;
	}
	if (scene->shadow == TRUE && (shadow(scene, inter)) != -1)
		return (rgb(0, 0, 0));
	c *= 2;
	return (rgb(obj.red * a + c, obj.green * a + c, obj.blue * a + c));
}
