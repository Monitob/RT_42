/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   shadow.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbenjami <rbenjami@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/12 18:36:46 by rbenjami          #+#    #+#             */
/*   Updated: 2014/02/15 16:38:13 by rbenjami         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

static t_obj	get_obj(t_obj obj, t_scene *scene)
{
	t_obj	o;

	o = obj;
	o.x = obj.x - scene->cam.x;
	o.y = obj.y - scene->cam.y;
	o.z = obj.z - scene->cam.z;
	return (o);
}

static float	shadow3(t_scene *scene, t_vector v, t_vector light_vector)
{
	float		shadow;
	int			i;
	t_obj		o;

	i = 0;
	while (i < scene->elem.nb_cylinder)
	{
		o = get_obj(scene->cylinder[i], scene);
		shadow = cylinder(scene, v, o, light_vector);
		if (shadow >= 0 && shadow < dist(v, light_vector))
			return (shadow);
		i++;
	}
	i = 0;
	while (i < scene->elem.nb_cone)
	{
		o = get_obj(scene->cone[i], scene);
		shadow = cone(scene, v, o, light_vector);
		if (shadow >= 0 && shadow < dist(v, light_vector))
			return (shadow);
		i++;
	}
	return (-1);
}

static float	shadow2(t_scene *scene, t_vector v, t_vector light_vector)
{
	t_obj		o;
	float		shadow;
	int			i;

	i = 0;
	while (i < scene->elem.nb_sphere)
	{
		o = get_obj(scene->sphere[i], scene);
		shadow = sphere(scene, v, o, light_vector);
		if (shadow >= 0 && shadow < dist(v, light_vector))
			return (shadow);
		i++;
	}
	return (shadow3(scene, v, light_vector));
}

float			shadow(t_scene *scene, t_vector v)
{
	t_vector	light_vector;
	float		shadow;
	int			i;

	i = 0;
	while (i < scene->elem.nb_proj)
	{
		light_vector.x = (scene->proj[i].x - scene->cam.x) - v.x;
		light_vector.y = (scene->proj[i].y - scene->cam.y) - v.y;
		light_vector.z = (scene->proj[i].z - scene->cam.z) - v.z;
		light_vector = normine(light_vector);
		if ((shadow = shadow2(scene, v, light_vector)) != -1)
			return (shadow);
		i++;
	}
	return (-1);
}
