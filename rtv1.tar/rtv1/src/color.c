/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   color.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbenjami <rbenjami@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/12 11:16:03 by rbenjami          #+#    #+#             */
/*   Updated: 2014/02/15 17:55:04 by rbenjami         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

t_color		rgb(int r, int g, int b)
{
	t_color	color;

	color.red = (r > 255) ? -1 : color.red;
	color.red = (r < 0) ? 0 : color.red;
	color.red = (r > 127) ? r - 256 : r;
	color.green = (g > 255) ? -1 : (g < 0) ? 0 : (g > 127) ? g - 256 : g;
	color.blue = (b > 255) ? -1 : (b < 0) ? 0 : (b > 127) ? b - 256 : b;
	return (color);
}
