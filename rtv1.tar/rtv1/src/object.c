/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   object.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbenjami <rbenjami@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/12 11:22:52 by rbenjami          #+#    #+#             */
/*   Updated: 2014/02/15 14:03:52 by rbenjami         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <math.h>
#include "rtv1.h"

float		sphere(t_scene *scene, t_vector cam, t_obj sphere, t_ray ray)
{
	float	a;
	float	b;
	float	c;

	a = rt(ray.x) + rt(ray.y) + rt(ray.z);
	b = ray.x * (cam.x - sphere.x);
	b += ray.y * (cam.y - sphere.y);
	b += ray.z * (cam.z - sphere.z);
	b *= 2;
	c = rt(cam.x - sphere.x);
	c += rt(cam.y - sphere.y);
	c += rt(cam.z - sphere.z);
	c -= rt(sphere.diameter / 2);
	return (res(a, b, c));
}

float		plan(t_scene *scene, t_vector cam, t_obj plan, t_ray ray)
{
	float		t;
	float		d;
	t_vector	norm;

	norm = normal_plan(plan.rot_x, plan.rot_y, plan.rot_z);
	d = sqrt(rt(plan.x) + rt(plan.y) + rt(plan.z));
	t = norm.x * (cam.x - plan.x);
	t += norm.y * (cam.y - plan.y);
	t += norm.z * (cam.z - plan.z) + d;
	t /= norm.x * ray.x + norm.y * ray.y + norm.z * ray.z;
	return (-t);
}

float		cylinder(t_scene *scene, t_vector cam, t_obj cylinder, t_ray ray)
{
	float	a;
	float	b;
	float	c;

	a = rt(ray.x) + rt(ray.z);
	b = ray.x * (cam.x - cylinder.x);
	b += ray.z * (cam.z - cylinder.z);
	b *= 2;
	c = rt(cam.x - cylinder.x);
	c += rt(cam.z - cylinder.z);
	c -= rt(cylinder.diameter / 2);
	return (res(a, b, c));
}

float		cone(t_scene *scene, t_vector cam, t_obj cone, t_ray ray)
{
	float	a;
	float	b;
	float	c;
	float	r;

	r = cone.diameter / 2;
	a = rt(ray.x) + rt(ray.z) - (rt(r) * rt(ray.y));
	b =	ray.x * (cam.x - cone.x);
	b += ray.z * (cam.z - cone.z);
	b -= ray.y * rt(r) * (cam.y - cone.y);
	b *= 2;
	c = rt(cam.x - cone.x);
	c += rt(cam.z - cone.z);
	c -= rt(r) * rt(cam.y - cone.y);
	return (res(a, b, c));
}
