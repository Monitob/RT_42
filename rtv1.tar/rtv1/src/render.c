/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   render.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbenjami <rbenjami@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/01 12:24:47 by rbenjami          #+#    #+#             */
/*   Updated: 2014/02/15 13:16:42 by rbenjami         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <mlx.h>
#include <libft.h>
#include "rtv1.h"

t_color		ray_trace(t_scene *s, t_vector ray, t_vector cam, t_color *c)
{
	t_dist		d;
	int			save;

	init_dist(&d);
	if (s->elem.nb_sphere > 0)
		*c = trace_spheres(s, cam, ray, &d.a);
	if (s->elem.nb_plan > 0)
	{
		save = trace_plan(s, cam, ray, &d.b);
		if ((d.b >= 0 && d.b < d.a) || (d.b >= 0 && d.a < 0))
			*c = get_light_at(s, multi(ray, d.b), s->plan[save]);
	}
	if (s->elem.nb_cylinder > 0)
	{
		save = trace_cylinder(s, cam, ray, &d.c);
		if (d.c >= 0 && (d.c < d.a || d.a < 0) && (d.c < d.b || d.b < 0))
			*c = get_light_at(s, multi(ray, d.c), s->cylinder[save]);
	}
	if (s->elem.nb_cone > 0)
	{
		save = trace_cone(s, cam, ray, &d.d);
		if (d.d >= 0 && (d.d < d.a || d.a < 0) && (d.d < d.b || d.b < 0)
					&& (d.d < d.c || d.c < 0))
			*c = get_light_at(s, multi(ray, d.d), s->cone[save]);
	}
}

int			fill_img(t_scene *scene, t_img *img)
{
	t_handler	h;

	h.cam = init_cam(scene);
	h.h = 0;
	while (h.h < WIN_H)
	{
		h.w = 0;
		while (h.w < WIN_W)
		{
			h.color = rgb(0, 0, 0);
			h.ray = vec3(-(WIN_W / 2) + h.w, (WIN_H / 2) - h.h, WIN_W);
			ray_trace(scene, h.ray, h.cam, &h.color);
			h.tmp = &img->data[h.h * img->sizeline + h.w * (img->bpp / 8)];
			h.tmp[0] = h.color.blue;
			h.tmp[1] = h.color.green;
			h.tmp[2] = h.color.red;
			h.w++;
		}
		h.h++;
	}
}

int			render(t_env *env, t_scene *scene)
{
	int		e;

	if ((env->mlx = mlx_init()) == NULL)
		return (error("mlx init error: ", NULL, FALSE, TRUE));
	if ((env->win = mlx_new_window(env->mlx, WIN_W, WIN_H, "RTv1")) == NULL)
		return (error("window error: ", NULL, FALSE, TRUE));
	env->screen.img = mlx_new_image(env->mlx, WIN_W, WIN_H);
	env->screen.data = mlx_get_data_addr(env->screen.img, &env->screen.bpp, \
												&env->screen.sizeline, &e);
	fill_img(scene, &env->screen);
	env->scene = scene;
	mlx_put_image_to_window(env->mlx, env->win, env->screen.img, 0, 0);
	mlx_expose_hook(env->win, expose_hook, env);
	mlx_key_hook(env->win, &key_hook, env);
	mlx_loop(env->mlx);
	return (0);
}
