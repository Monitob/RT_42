/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   math.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbenjami <rbenjami@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/12 11:15:03 by rbenjami          #+#    #+#             */
/*   Updated: 2014/02/14 20:31:31 by rbenjami         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <math.h>
#include "rtv1.h"

float		rt(float val)
{
	return (val * val);
}

float		res(float a, float b, float c)
{
	float	det;
	float	t;
	float	t2;

	det = rt(b) - 4 * a * c;
	t = -1;
	if (det >= 0)
	{
		t = (-b + sqrt(det)) / (a + a);
		if ((t2 = (-b - sqrt(det)) / (a + a)) < t)
			t = t2;
	}
	return (t);
}

t_vector		normal_plan(float rotx, float roty, float rotz)
{
	t_vector	vec;

	vec.x = 0;
	vec.y = 1;
	vec.z = 0;
	if (rotx)
	{
		vec.y = cos(M_PI * rotx / 180) - sin(M_PI * rotx / 180);
		vec.z = sin(M_PI * rotx / 180) + cos(M_PI * rotx / 180);
	}
	else if (roty)
	{
		vec.x = cos(M_PI * roty / 180) + sin(M_PI * roty / 180);
		vec.z = -sin(M_PI * roty / 180) + cos(M_PI * roty / 180);
	}
	else if (rotz)
	{
		vec.x = cos(M_PI * rotz / 180) - sin(M_PI * rotz / 180);
		vec.y = sin(M_PI * rotz / 180) + cos(M_PI * rotz / 180);
	}
	vec = normine(vec);
	return (vec);
}
