/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbenjami <rbenjami@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/14 20:35:49 by rbenjami          #+#    #+#             */
/*   Updated: 2014/02/14 20:37:38 by rbenjami         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

t_obj		init_obj(int type)
{
	t_obj		obj;

	obj.x = 0;
	obj.y = 0;
	obj.z = 0;
	obj.rot_x = 0;
	obj.rot_y = 0;
	obj.rot_z = 0;
	obj.red = 0;
	obj.green = 0;
	obj.blue = 0;
	obj.intens = 0;
	obj.diameter = 0;
	obj.type = type;
	return (obj);
}

void		init_dist(t_dist *d)
{
	d->a = -1;
	d->b = -1;
	d->b = -1;
	d->c = -1;
	d->d = -1;
}

t_vector	init_cam(t_scene *scene)
{
	t_vector	cam;

	cam.x = scene->cam.x;
	cam.y = scene->cam.y;
	cam.z = scene->cam.z;
	return (cam);
}
