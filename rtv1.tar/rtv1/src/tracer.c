/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tracer.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbenjami <rbenjami@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/13 17:40:19 by rbenjami          #+#    #+#             */
/*   Updated: 2014/02/14 17:28:47 by rbenjami         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

t_color	trace_spheres(t_scene *scene, t_vector cam, t_ray ray, float *dist)
{
	int		i;
	int		save;
	float	t;
	float	t2;

	i = 1;
	save = 0;
	t = sphere(scene, cam, scene->sphere[0], ray);
	while (i < scene->elem.nb_sphere)
	{
		t2 = sphere(scene, cam, scene->sphere[i], ray);
		if (t < 0 || (t2 < t && t2 >= 0))
		{
			save = i;
			t = t2;
		}
		i++;
	}
	*dist = t;
	if (t >= 0)
		return (get_light_at(scene, multi(ray, t), scene->sphere[save]));
	return (rgb(0, 0, 0));
}

int		trace_cylinder(t_scene *scene, t_vector cam, t_ray ray, float *dist)
{
	int		i;
	int		save;
	float	t;
	float	t2;

	i = 1;
	save = 0;
	t = cylinder(scene, cam, scene->cylinder[0], ray);
	while (i < scene->elem.nb_cylinder)
	{
		t2 = cylinder(scene, cam, scene->cylinder[i], ray);
		if (t < 0 || (t2 < t && t2 >= 0))
		{
			save = i;
			t = t2;
		}
		i++;
	}
	*dist = t;
	return (save);
}

int		trace_cone(t_scene *scene, t_vector cam, t_ray ray, float *dist)
{
	int		i;
	int		save;
	float	t;
	float	t2;

	i = 1;
	save = 0;
	t = cone(scene, cam, scene->cone[0], ray);
	while (i < scene->elem.nb_cone)
	{
		t2 = cone(scene, cam, scene->cone[i], ray);
		if (t < 0 || (t2 < t && t2 >= 0))
		{
			save = i;
			t = t2;
		}
		i++;
	}
	*dist = t;
	return (save);
}

int		trace_plan(t_scene *scene, t_vector cam, t_ray ray, float *dist)
{
	int		i;
	int		save;
	float	t;
	float	t2;

	i = 1;
	save = 0;
	t = plan(scene, cam, scene->plan[0], ray);
	while (i < scene->elem.nb_plan)
	{
		t2 = plan(scene, cam, scene->plan[i], ray);
		if (t < 0 || (t2 < t && t2 >= 0))
		{
			save = i;
			t = t2;
		}
		i++;
	}
	*dist = t;
	return (save);
}
