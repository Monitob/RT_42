/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vector.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rbenjami <rbenjami@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/05 11:33:53 by rbenjami          #+#    #+#             */
/*   Updated: 2014/02/14 20:26:49 by rbenjami         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <math.h>
#include "rtv1.h"

t_vector	normine(t_vector v)
{
	t_vector	new_vector;
	float		norm;

	norm = sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
	new_vector.x = v.x / norm;
	new_vector.y = v.y / norm;
	new_vector.z = v.z / norm;
	return (new_vector);
}

float		dist(t_vector v1, t_vector v2)
{
	float		dist;

	dist = sqrt(rt(v1.x - v2.x) + rt(v1.y - v2.y) + rt(v1.z - v2.z));
	return (dist);
}

t_vector	vec3(float x, float y, float z)
{
	t_vector	vec;

	vec.x = x;
	vec.y = y;
	vec.z = z;
	vec = normine(vec);
	return (vec);
}

t_vector	multi(t_vector vector, float m)
{
	t_vector	new_vector;

	new_vector.x = vector.x * m;
	new_vector.y = vector.y * m;
	new_vector.z = vector.z * m;
	return (new_vector);
}

float		dot(t_vector a, t_vector b)
{
	float	angle;

	angle = a.x * b.x + a.y * b.y + a.z * b.z;
	return (angle);
}
